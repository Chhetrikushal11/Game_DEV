#pragma once
#include <memory>
#include <unordered_map>
#include <string>
#include <glm/vec3.hpp>
// need unordered map for texture  management in material later
namespace GAMEDEV_ENGINE 
{
    class ShaderProgram; // forward declaration
    class Texture;

    class Material
    {
        public:
        // adding shader program using set method
        void SetShaderProgram(std::shared_ptr<ShaderProgram> shaderProgram);
        // we are creating the shader program but using shader pointer to avoid copying.
        // we dont want to copy shader program object because its heavy object

        // to set the float parameters in the material
        void SetFloatParams(const std::string& name, float value);
        // to get the float parameters in the material

        // to set the float with two value
        void SetFloatParams2f(const std::string& name, float v0, float v1);

        // to set the float with 3 value 
        void SetFloatParams3f(const std::string& name, const glm::vec3& value);

        // to set the texture
        void SetTextureParams(const std::string& name,const std::shared_ptr<Texture>& texture);

        // now to bind the material 
        void Bind() const;

        // here we add get method for ShaderProgram
        ShaderProgram* GetShaderProgram() const {return _mShaderProgram.get();}

        // loading static shared ptr for Material
        static std::shared_ptr<Material> Load(const std::string& path);
        private :
        std::shared_ptr<ShaderProgram> _mShaderProgram;
        std::unordered_map<std::string, float> _mFloatParams;
        // need container which will hold 2 parameter for each key
        std::unordered_map<std::string, std::pair<float, float>> _mFloat2Params;
        // adding container for texture
        std::unordered_map<std::string, std::shared_ptr<Texture>> _mTextureContainers;

        // to color setup different
        std::unordered_map<std::string, glm::vec3> _mFloat3Params;
    };
}