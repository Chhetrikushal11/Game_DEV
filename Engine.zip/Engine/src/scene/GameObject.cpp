﻿#include "Engine/scene/GameObject.h"
#include "Engine/Engine.h"
#include "Engine/graphics/VertexLayout.h"
#include "Engine/render/material.h"
#include "Engine/render/mesh.h"
#include "Engine/graphics/Texture.h"
#include "Engine/scene/Component/MeshComponent.h"
#include "Engine/scene/Component/AnimationComponent.h"

#include <glm/gtc/matrix_transform.hpp> // for glm::translate, glm::rotate, glm::scale
#include <glm/glm.hpp> 
#include <glm/gtc/type_ptr.hpp>
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/matrix_decompose.hpp>


// to load gltf we need to define CGLTF_IMPLEMENTATION
#define CGLTF_IMPLEMENTATION
#include <cgltf.h>

namespace GAMEDEV_ENGINE
{
    void GameObject::Init()
    {


    }

    void GameObject::LoadProperties(const nlohmann::json& json)
    {

    }
    void GameObject::Update(float deltaTime)
    {
        if (!_mActive)
        {
            return;
        }
        // iterate the _mComponents and call their update methods
        for (auto& component : _mComponents)
        {
            component->Update(deltaTime);
        
        }
        // here we iterate over children containers and call their update methods
        for (auto childrenIt = _mChildren.begin(); childrenIt != _mChildren.end(); )
        {
            GameObject* child = childrenIt->get();
            if(child->IsAlive())
            {
                child->Update(deltaTime);
                ++childrenIt;
            }
            else
            {
                // remove the child from the children vector
                childrenIt = _mChildren.erase(childrenIt);
            }
        }
    }

    void GameObject::SetName(const std::string& name)
    {
        _mName = name;
    }

    bool GameObject::SetParent(GameObject* parent)
    {
        if (!_mScene)
        {
            return false;
        }

        return _mScene->SetParent(this, parent);
           
    }

    // void GameObject::SetParent(GameObject* parent)
    // {
    //     _mParent = parent;
    // }

    void GameObject::AddComponent(Component* component)
    {
        if(component)
        {
            _mComponents.emplace_back(component);
            component->_mGameObjectOwner = this; // setting the owner pointer
            // this can be access the component member as GameObject is declared as friend class in Component class
            component->Init();

        }
    }



    void GameObject::MarkForDestroy()
    {
        if(_misAlive)
        {
            _misAlive = false;
        }
    }

    // for local transformation matrix
    glm::mat4 GameObject::GetLocalTransformMatrix() const
    {
        // this method combines translation, rotation, and scaling into a single transformation matrix

        // step 1 : Creating the identity matrix
        glm::mat4 identityMatrix = glm::mat4(1.0f); 
        
        // step 2: Translation first
        glm::mat4 translationMatrix = glm::translate(identityMatrix, _mPosition);

        // step 3: Rotation second (applying in ZYX order)
        
            // --- using quaternion --
        glm::mat4 rotationMatrix = glm::mat4_cast(_mRotation); // here glm::mat4_cast simply convert quat to mat4 for rotation

        //glm::mat4 rotationXMatrix = glm::rotate(identityMatrix, _mRotation.x, glm::vec3(1.0f, 0.0f, 0.0f)); // rotate around X axis
        //glm::mat4 rotationYMatrix = glm::rotate(identityMatrix, _mRotation.y, glm::vec3(0.0f, 1.0f, 0.0f)); // rotate around X axis
        //glm::mat4 rotationZMatrix = glm::rotate(identityMatrix, _mRotation.z, glm::vec3(0.0f, 0.0f, 1.0f)); // rotate around X axis
        // combine rotations
       /* glm::mat4 rotationMatrix = rotationZMatrix * rotationYMatrix * rotationXMatrix;*/



        // step 4: Scaling last
        glm::mat4 scaleMatrix = glm::scale(identityMatrix, _mScale);

        // step 5: combine all transformations: Translation * Rotation * Scale  
        return translationMatrix * rotationMatrix * scaleMatrix;
    }   
    
    // for world transformation matrix
    glm::mat4 GameObject::GetWorldTransformMatrix() const
    {
        if(_mParent)
        {
            return _mParent->GetWorldTransformMatrix() * GetLocalTransformMatrix();
        }
        else
        {
            return GetLocalTransformMatrix();
        }   
        // this way every game object can be compute with respect to world scene rather than just local space
    } 

    // for world position
    glm::vec3 GameObject::GetWorldPosition()
    {
        glm::vec4 hom = GetWorldTransformMatrix() * glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
        return glm::vec3(hom) / hom.w;
    }
    
    void ParseGLTFNode(cgltf_node* node, GameObject* parent, std::filesystem::path& folder)
    {
        // this function will create the gameobject for the node
         auto object = parent->GetScene()->CreateGameObject(node->name, parent);

        // handling transformation
        if (node->has_matrix)
        {
            auto mat = glm::make_mat4(node->matrix);
            glm::vec3 translation, scale, skew;
            glm::vec4  perspective;
            glm::quat orientation;
            glm::decompose(mat, scale, orientation, translation, skew, perspective);

            object->SetPosition(translation);
            object->SetRotation(orientation);
            object->SetScale(scale);
        }
        else
        {
            if (node->has_translation)
            {
                object->SetPosition(glm::vec3(node ->translation[0],
                    node->translation[1],
                    node->translation[2]));
            }
            if (node->has_rotation)
            {
                object->SetRotation(glm::quat(node->rotation[3],
                    node->rotation[0],
                    node->rotation[1],
                    node->rotation[2]));
            }
            if (node->has_scale)
            {
                object->SetScale(glm::vec3(node->scale[0],
                    node->scale[1],
                    node->scale[2]));
            }
        }

        if (node->mesh)
        {
            for (cgltf_size pi = 0; pi < node->mesh->primitives_count; ++pi)
            {
                auto& primitive = node->mesh->primitives[pi];
                if (primitive.type != cgltf_primitive_type_triangles)
                {
                    continue;
                }
                auto readFloats = [](const cgltf_accessor* acc, cgltf_size i, float* out, int n)
                    {
                        std::fill(out, out + n, 0.0f);
                        return cgltf_accessor_read_float(acc, i, out, n) == 1;


                    };

                auto readIndex = [](const cgltf_accessor* acc, cgltf_size i)
                    {
                        cgltf_uint out = 0;
                        cgltf_bool ok = cgltf_accessor_read_uint(acc, i, &out, 1);
                        return ok ? static_cast<uint32_t>(out) : 0;
                    };

                // here we process primitve loading
                VertexLayout vertexLayout;
                cgltf_accessor* accessors[4] = { nullptr, nullptr, nullptr, nullptr };

                // iterate through all the attributes
                for (cgltf_size ai = 0; ai < primitive.attributes_count; ++ai)
                {
                    auto& attr = primitive.attributes[ai];
                    auto acc = attr.data;
                    if (!acc)
                    {
                        continue;
                    }

                    VertexElement element;
                    element.type = GL_FLOAT; //why?

                    switch (attr.type)
                    {
                    case cgltf_attribute_type_position:
                    {
                        accessors[VertexElement::PositionIndex] = acc;
                        element.index = VertexElement::PositionIndex;
                        element.size = 3;
                    }
                    break;
                    case cgltf_attribute_type_color:
                    {
                        // working with channel 0
                        if (attr.index != 0)
                        {
                            continue;
                        }
                        accessors[VertexElement::ColorIndex] = acc;
                        element.index = VertexElement::ColorIndex;
                        element.size = 3;
                    }
                    break;
                    case cgltf_attribute_type_texcoord:  // number of tex coordinates
                    {
                        // working with channel 0
                        if (attr.index != 0)
                        {
                            continue;
                        }
                        accessors[VertexElement::UVIndex] = acc;
                        element.index = VertexElement::UVIndex;
                        element.size = 2;
                    }
                    break;
                    case cgltf_attribute_type_normal:  // number of tex coordinates
                    {
                        accessors[VertexElement::NormalIndex] = acc;
                        element.index = VertexElement::NormalIndex;
                        element.size = 3;
                    }
                    break;
                    default:
                        continue;
                    }

                    // need to push to vertex layout
                    if (element.size > 0)
                    {
                        element.offset = vertexLayout.stride;
                        vertexLayout.stride += element.size * sizeof(float);
                        vertexLayout.elements.push_back(element);
                    }
                }
                // after we get layout we can finally get the buffer
                if (!accessors[VertexElement::PositionIndex])
                {
                    continue;
                }

                auto vertexCount = accessors[VertexElement::PositionIndex]->count;
                std::vector<float> vertices;
                vertices.resize((vertexLayout.stride / sizeof(float))* vertexCount);

                for (cgltf_size vi = 0; vi < vertexCount; ++vi)
                {
                    for (auto& el : vertexLayout.elements)
                    {
                        if (!accessors[el.index])
                        {
                            continue;
                        }

                        auto index = (vi * vertexLayout.stride + el.offset) / sizeof(float);
                        float* outData = &vertices[index];
                        readFloats(accessors[el.index], vi, outData, el.size);
                    }
                }
                std::shared_ptr<Mesh> mesh;
                if (primitive.indices)
                {
                    auto indexCount = primitive.indices->count;
                    std::vector<uint32_t> indices(indexCount);
                    for (cgltf_size i = 0; i < indexCount; ++i)
                    {
                        indices[i] = readIndex(primitive.indices, i);
                    }
                    mesh = std::make_shared<Mesh>(vertexLayout, vertices, indices);
                }

                else
                {
                    mesh = std::make_shared<Mesh>(vertexLayout, vertices);
                }
                
                // gltf material are PBR based

                auto mat = std::make_shared<Material>();
                mat->SetShaderProgram(Engine::GetInstance().GetGraphicsAPI().GetDefaultShaderProgram());
                
                if (primitive.material)
                {
                    auto gltfMat = primitive.material;
                    if (gltfMat->has_pbr_metallic_roughness)
                    {
                        auto pbr = gltfMat->pbr_metallic_roughness;
                        auto texture = pbr.base_color_texture.texture;
                        if (texture && texture->image)
                        {
                            if (texture->image->uri)
                            {
                                auto path = folder / std::string(texture->image->uri);
                                auto tex = Engine::GetInstance().GetTextureManager().GetorLoadTexture(path.string());
                                mat->SetTextureParams("baseColorTexture", tex);
                            }
                        }
                    }
                    else if (gltfMat->has_pbr_specular_glossiness)
                    {
                        auto pbr = gltfMat->pbr_specular_glossiness;
                        auto texture = pbr.diffuse_texture.texture;
                        if (texture && texture->image)
                        {
                            if (texture->image->uri)
                            {
                                auto path = folder / std::string(texture->image->uri);
                                auto tex = Engine::GetInstance().GetTextureManager().GetorLoadTexture(path.string());
                                mat->SetTextureParams("baseColorTexture", tex);
                            }
                        }
                    }

                }

                object->AddComponent(new MeshComponent(mat, mesh));
            }
        }
        for (cgltf_size ci = 0; ci < node->children_count; ++ci)
        {
            ParseGLTFNode(node->children[ci], object, folder);
        }
    }

    auto ReadScalar = [](cgltf_accessor* acc, cgltf_size index)
        {
            float res = 0.0f;
            cgltf_accessor_read_float(acc, index, &res, 1);
            return res;
        };

    auto ReadVec3 = [](cgltf_accessor* acc, cgltf_size index)
        {
            glm::vec3 res;
            cgltf_accessor_read_float(acc, index, glm::value_ptr(res),3);
            return res;
        };
    
    auto ReadQuat = [](cgltf_accessor* acc, cgltf_size index)
        {
            float res[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
            cgltf_accessor_read_float(acc, index, res, 4);
            return glm::quat(res[3], res[0], res[1],res[2]);
        };
    
    auto ReadTimes = [](cgltf_accessor* acc, std::vector<float>& outTimes)
        {
            outTimes.resize(acc->count);
            for (cgltf_size i = 0; i < acc->count; ++i)
             {
                outTimes[i] = ReadScalar(acc, i);
              }
        };

    auto ReadOutputVec3 = [](cgltf_accessor* acc, std::vector<glm::vec3>& outValues)
        {
            outValues.resize(acc->count);
            for (cgltf_size i = 0; i < acc->count; ++i)
            {
                outValues[i] = ReadVec3(acc, i);
            }
        };

    auto ReadOutputQuat = [](cgltf_accessor* acc, std::vector<glm::quat>& outValues)
        {
            outValues.resize(acc->count);
            for (cgltf_size i = 0; i < acc->count; ++i)
            {
                outValues[i] = ReadQuat(acc, i);
            }
        };
    
    GameObject* GameObject::LoadGLTF(const std::string& path, Scene* gameScene)
    {
        // we will follow same procedure we follow in mesh load
        // step 1 :Read the file content
         // we can load file using GetInstance()
        auto contents = Engine::GetInstance().GetAssetFileSystem().LoadAssetFileText(path);
        if (contents.empty())
        {
            return nullptr;
        }

        if (!gameScene)
        {
            return nullptr;
        }

        cgltf_options options = {};
        cgltf_data* data = nullptr;
        cgltf_result res = cgltf_parse(&options, contents.data(), contents.size(), &data);
        if (res != cgltf_result_success)
        {
            return nullptr;
        }
        auto fullPath = Engine::GetInstance().GetAssetFileSystem().GetAssetsFolder() / path;
        // also need to store relative folder path
        auto fullFolderPath = fullPath.remove_filename();
        auto relativeFolderPath = std::filesystem::path(path).remove_filename();
        res = cgltf_load_buffers(&options, data, fullPath.remove_filename().string().c_str());
        if (res != cgltf_result_success)
        {
            cgltf_free(data);
            return nullptr;
        }

        // gltf store file data as node
            // a gltf can have more than one nodes so we need one root gameobject to hold everything
        auto resultObject = gameScene->CreateGameObject("Result");
        auto scene = &data->scenes[0]; // to use it as pointer
       
        for (cgltf_size i = 0; i < scene->nodes_count; ++i)
        {
            auto node = scene->nodes[i];
            ParseGLTFNode(node, resultObject, relativeFolderPath);
        }

        std::vector<std::shared_ptr<AnimationClip>> clips;
        for (cgltf_size ai = 0; ai < data->animations_count; ++ai)
        {
            //ai - animation index
            auto& anim = data->animations[ai];
            auto clip = std::make_shared<AnimationClip>();
            clip->name = anim.name ? std::string(anim.name) : std::string("noname");
            clip->duration = 0.0f;

            std::unordered_map<cgltf_node*, size_t> trackIndexOf;

            auto GetorCreateTrack = [&](cgltf_node* node) -> TransformTrack&
                {
                    auto it = trackIndexOf.find(node);
                    if (it != trackIndexOf.end())
                    {
                        return clip->tracks[it->second];
                    }

                    TransformTrack track;
                    track.targetName = node->name;
                    clip->tracks.push_back(track);
                    size_t idx = clip->tracks.size() - 1;
                    trackIndexOf[node] = idx;
                    return clip->tracks[idx];
                };

            for (cgltf_size ci = 0; ci < anim.channels_count; ++ci)
            {
                // ci = channel index
                auto& channel = anim.channels[ci];
                auto sampler = channel.sampler;

                if (!channel.target_node || !sampler || !sampler->input || !sampler->output)
                {
                    continue;
                }
                std::vector<float> times;
                ReadTimes(sampler->input, times);

                auto& track = GetorCreateTrack(channel.target_node);
                switch (channel.target_path)
                {
                case cgltf_animation_path_type_translation:
                {
                    std::vector<glm::vec3> values;
                    ReadOutputVec3(sampler->output, values);
                    track.positions.resize(times.size());
                    for (size_t i = 0; i < times.size(); ++i)
                    {
                        track.positions[i].time = times[i];
                        track.positions[i].value = values[i];
                    }
                }
                break;
                case cgltf_animation_path_type_rotation:
                {
                    std::vector<glm::quat> values;
                    ReadOutputQuat(sampler->output, values);
                    track.rotations.resize(times.size());
                    for (size_t i = 0; i < times.size(); ++i)
                    {
                        track.rotations[i].time = times[i];
                        track.rotations[i].value = values[i];
                    }
                }
                break;
                case cgltf_animation_path_type_scale:
                {
                    std::vector<glm::vec3> values;
                    ReadOutputVec3(sampler->output, values);
                    track.scales.resize(times.size());
                    for (size_t i = 0; i < times.size(); ++i)
                    {
                        track.scales[i].time = times[i];
                        track.scales[i].value = values[i];
                    }
                }
                break;
                default:
                    break;
                }

                clip->duration = std::max(clip->duration, times.back());
            }
            clips.push_back(std::move(clip));

            // Debug output for this animation
            std::string animName = clips.back()->name;
            if (animName.empty()) {
                animName = "unnamed";
            }

            std::cout << "Animation loaded: " << animName
                << " | Duration: " << clips.back()->duration
                << " | Tracks: " << clips.back()->tracks.size() << std::endl;
        }  // ✅ CLOSE THE ANIMATION LOOP HERE!

        // ✅ NOW create AnimationComponent AFTER all animations are parsed
        if (!clips.empty())
        {
            std::cout << "Creating AnimationComponent with " << clips.size() << " clips" << std::endl;

            auto animComp = new AnimationComponent();
            resultObject->AddComponent(animComp);

            for (auto& clip : clips)
            {
                std::string clipName = clip->name;
                if (clipName.empty()) {
                    clipName = "unnamed";
                }

                animComp->RegisterClip(clipName, clip);
                std::cout << "  Registered: " << clipName << std::endl;
            }
        }

        cgltf_free(data);
        return resultObject;
    }

    void GameObject::SetWorldPosition(const glm::vec3& pos)
    {
        if (_mParent)
        {
            glm::mat4 parentWorld = _mParent->GetWorldTransformMatrix();
            glm::mat4 invParentWorld = glm::inverse(parentWorld);
            glm::vec4 localPos = invParentWorld * glm::vec4(pos, 1.0f);
            SetPosition(glm::vec3(localPos) / localPos.w);
        }
        else
        {
            SetPosition(pos);
        }
    }

    glm::vec3 GameObject::GetWorldPosition1() const
    {
        if (_mParent)
        {
            return _mParent->GetWorldPosition1() * _mPosition;
        }
        else
        {
            return _mPosition;
        }
    }

    void GameObject::SetWorldRotation(const glm::quat& rot)
    {
        if (_mParent)
        {
            glm::quat parentWorldRot = _mParent->GetWorldRotation();
            glm::quat invParentWorldRot = glm::inverse(parentWorldRot);
            glm::quat newLocalRot = invParentWorldRot * rot;
            SetRotation(newLocalRot);
        }
        else
        {
            SetRotation(rot);
        }
    }

    glm::quat GameObject::GetWorldRotation() const
    {
        if (_mParent)
        {
            return _mParent->GetWorldRotation() * _mRotation;
        }
        else
        {
            return _mRotation;
        }
    }

    void GameObject::SetActive(bool active)
    {
        _mActive = active;
    }

    GameObject* GameObject::FindChildByName(const std::string& name)
    {
        if (_mName == name)
        {
            return this;
        }

        for (auto& child : _mChildren)
        {
            if (auto res = child->FindChildByName(name))
            {
                return res;
            }
        }

        return nullptr;
    }

    GameObjectFactory& GameObjectFactory::GetInstance()
    {
        static GameObjectFactory instance;
        return instance;
    }

    GameObject* GameObjectFactory::CreateGameObject(const std::string& typeName)
    {
        auto it = _mCreators.find(typeName);
        if (it == _mCreators.end())
        {
            return nullptr;
        }

        return it->second->CreateGameObject();
    }
} // namespace GAMEDEV_ENGINE   